/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    unoptimized: true, // Required for AWS Amplify static hosting
  },
  // Ensure static export compatibility
  trailingSlash: false,
};

export default nextConfig;
